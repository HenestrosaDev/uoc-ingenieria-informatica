package jpa;
import java.io.Serializable;
import java.util.*;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.*;

@Entity
@Table(name="myhealth.specialities")
public class MedicalSpecialityJPA implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "name")
	private String name;
	@Column(name = "description")
	private String description;
	
	public MedicalSpecialityJPA() {
		super();
	}
	
	public MedicalSpecialityJPA(String name) {
		super();
		this.name = name;
	}
	
	public MedicalSpecialityJPA(String name, String description) {
		super();
		this.name = name;
		this.description = description;
	}

	@Id
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Column(name = "description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

}