package jpa;
import java.io.Serializable;
import java.util.*;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.persistence.*;

@ManagedBean(name = "userData", eager = true)
@SessionScoped
public class DataTest implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String name = "1";
	private String description = "desc";
	
	public DataTest() {
		super();
	}
	
	public DataTest(String name) {
		super();
		this.name = name;
	}
	
	public DataTest(String name, String description) {
		super();
		this.name = name;
		this.description = description;
	}

	@Id
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Column(name = "description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

}