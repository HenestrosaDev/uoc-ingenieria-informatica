package managedbean;

import java.io.Serializable;
import java.util.logging.Logger;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(name = "specialitiesNavigation", eager = true)
@SessionScoped
public class SpecialitiesNavigation implements Serializable {
	private static final long serialVersionUID = -8241821215695600948L;
	private final static Logger LOG = Logger.getLogger("managedbean.SpecialitiesNavigation");

	public String createSpecialityView() {
		LOG.info("surfing createSpecialityView");
		return "createSpecialityView";
	}
	
	public String deleteSpecialityView() {
		LOG.info("surfing deleteSpecialityView");
		return "deleteSpecialityView";
	}
	
	public String updateSpecialityView() {
		LOG.info("surfing updateSpecialityView");
		return "updateSpecialityView";
	}
	
	public String listAllSpecialitiesView() {
		LOG.info("surfing listAllSpecialitiesView");
		return "listAllSpecialitiesView";
	}
}
