package managedbean;

import java.util.List;

import jpa.MedicalSpecialityJPA;

public interface ISystemAdministrationPresentation {
	public List<MedicalSpecialityJPA> listAllMedicalSpecialities();
	public void addMedicalSpeciality();
	public String deleteMedicalSpeciality();
	public String updateMedicalSpeciality();
}
