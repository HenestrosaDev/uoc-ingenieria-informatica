package managedbean;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import ejb.ISystemAdministrationBusiness;
import ejb.SystemAdministrationBusiness;
import jpa.MedicalSpecialityJPA;

@ManagedBean(name = "specialities")
@SessionScoped
public class SystemAdministrationPresentation implements ISystemAdministrationPresentation {
	private final static Logger LOG = Logger.getLogger("managedbean.SystemAdministrationPresentation");
	
	private String name;
	private String description;
	private String result;
	
	private List<MedicalSpecialityJPA> medicalSpecialities;
	public void setMedicalSpecialities(List<MedicalSpecialityJPA> medicalSpecialities) {
		this.medicalSpecialities = medicalSpecialities;
	}

	@EJB
	private ISystemAdministrationBusiness systemAdministrationBusiness;

	public List<MedicalSpecialityJPA> listAllMedicalSpecialities() {
		LOG.info("here in listAllMedicalSpecialities");
		systemAdministrationBusiness = getMedicalSpecialitiesJPAInstance();
		LOG.info("the list: " + systemAdministrationBusiness.listAllMedicalSpecialities().toString());
		return systemAdministrationBusiness.listAllMedicalSpecialities();
	}
	
	public List<MedicalSpecialityJPA> getMedicalSpecialities() {
		if(this.medicalSpecialities == null) {
			medicalSpecialities = new ArrayList<>();
		}
		LOG.info("before query listAllMedicalSpecialities");
		return listAllMedicalSpecialities();
	}

	public void addMedicalSpeciality() {
		LOG.info("here in addMedicalSpeciality");
		systemAdministrationBusiness = getMedicalSpecialitiesJPAInstance();
		systemAdministrationBusiness.addMedicalSpeciality(this.getName(), this.getDescription());
		this.setResult(String.format("Speciality whit name '%s' added", name));
	}

	public String deleteMedicalSpeciality() {
		LOG.info("here in deleteMedicalSpeciality");
		systemAdministrationBusiness = getMedicalSpecialitiesJPAInstance();
		systemAdministrationBusiness.deleteMedicalSpeciality(this.getName());
		this.setResult(String.format("Speciality whit name '%s' deleted", name));
		return "deleteSpecialityView";
	}

	public String updateMedicalSpeciality() {
		LOG.info("here in updateMedicalSpeciality");
		systemAdministrationBusiness = getMedicalSpecialitiesJPAInstance();
		systemAdministrationBusiness.updateMedicalSpeciality(this.getName(), this.getDescription());
		this.setResult(String.format("Speciality whit name '%s' updated", name));
		return "updateSpecialityView";
	}
	
	public SystemAdministrationBusiness getMedicalSpecialitiesJPAInstance() {
		Properties properties = System.getProperties();
		LOG.info("total properties: " + properties.size());
		try {
			Context ctx = new InitialContext(properties);
			LOG.info("context from properties");
			systemAdministrationBusiness = (SystemAdministrationBusiness) ctx.lookup("java:app/MedicalSpecialitiesJEE.jar/SystemAdministrationBusiness!ejb.ISystemAdministrationBusiness");
			LOG.info("systemAdministrationBusiness: " + ((SystemAdministrationBusiness) this.systemAdministrationBusiness).getClass().getMethods().toString());
			return (SystemAdministrationBusiness) this.systemAdministrationBusiness;
		} catch (NamingException e) {
			LOG.info("returning null context, en exception threw, into the catch block!");
		}
		LOG.info("returning null context, en exception threw");
		return null;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}