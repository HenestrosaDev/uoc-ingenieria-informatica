package ejb;

import java.util.List;

import javax.ejb.Remote;

import jpa.MedicalSpecialityJPA;

@Remote
public interface ISystemAdministrationBusiness {
	  public List<MedicalSpecialityJPA> listAllMedicalSpecialities();
	  public void addMedicalSpeciality(String name, String description);
	  public void deleteMedicalSpeciality(String name);
	  public void updateMedicalSpeciality(String name, String description);
}
