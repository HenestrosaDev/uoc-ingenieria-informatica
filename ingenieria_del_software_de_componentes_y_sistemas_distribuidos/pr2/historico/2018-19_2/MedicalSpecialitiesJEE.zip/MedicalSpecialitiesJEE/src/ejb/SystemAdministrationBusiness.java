package ejb;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import jpa.MedicalSpecialityJPA;

@Stateless
public class SystemAdministrationBusiness implements ISystemAdministrationBusiness {

	@PersistenceContext(unitName = "myhealth")
	private EntityManager entman;

	@SuppressWarnings("unchecked")
	public List<MedicalSpecialityJPA> listAllMedicalSpecialities() {
		return (List<MedicalSpecialityJPA>)entman.createQuery("select name, description from specialities").getResultList();
	}

	public void addMedicalSpeciality(String name, String description) {
		this.entman.getTransaction().begin();
		this.entman.persist(new MedicalSpecialityJPA(name, description));
		this.entman.getTransaction().commit();
	}

	public void deleteMedicalSpeciality(String name) {
		this.entman.getTransaction().begin();
		MedicalSpecialityJPA medicalSpecialityJPA = this.entman.find(MedicalSpecialityJPA.class, name);
		this.entman.remove(medicalSpecialityJPA);
		this.entman.getTransaction().commit();
	}

	public void updateMedicalSpeciality(String name, String description) {
		this.entman.getTransaction().begin();
		this.entman.merge(new MedicalSpecialityJPA(name, description));
		this.entman.getTransaction().commit();
	}

}